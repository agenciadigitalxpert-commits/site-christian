// Instituto Christian Andrade — interações do site
document.addEventListener('DOMContentLoaded', () => {

  // menu mobile
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if(toggle && nav){
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => nav.classList.remove('open'));
    });
  }

  // marca link ativo do menu conforme a página atual
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.main-nav a[href]').forEach(link => {
    const href = link.getAttribute('href');
    if(href === path){ link.classList.add('active'); }
  });

  // acordeão FAQ: mantém só um aberto por vez (opcional, suave)
  document.querySelectorAll('.faq details').forEach(d => {
    d.addEventListener('toggle', () => {
      if(d.open){
        document.querySelectorAll('.faq details').forEach(other => {
          if(other !== d) other.open = false;
        });
      }
    });
  });

  // validação simples do formulário de contato
  const form = document.querySelector('#form-contato');
  if(form){
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const status = form.querySelector('.form-status');
      const nome = form.nome.value.trim();
      const telefone = form.telefone.value.trim();
      if(!nome || !telefone){
        status.textContent = 'Preencha nome e telefone para enviarmos seu contato.';
        status.style.color = '#B25A38';
        return;
      }
      const unidade = form.unidade ? form.unidade.value : '';
      const msg = `Olá, Instituto Christian Andrade! Meu nome é ${nome}. Gostaria de agendar uma avaliação${unidade ? ' na unidade ' + unidade : ''}.`;
      window.open(`https://api.whatsapp.com/send?phone=5541996962223&text=${encodeURIComponent(msg)}`, '_blank');
      status.textContent = 'Perfeito! Abrimos o WhatsApp para você concluir o contato.';
      status.style.color = '#3E5A4E';
      form.reset();
    });
  }
});
